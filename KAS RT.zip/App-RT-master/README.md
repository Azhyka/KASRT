

| Nama  |  Nim | Kelas |
| ------------- | ------------- |------------- |
| Agus Setiawan  | 312210193 | TI 22 A2 |
| Rian Fauza  | 312210083| TI 22 A2 |

### RT Elektronik Mobile
adalah sebuah aplikasi mobile yang dirancang khusus untuk mempermudah pengelolaan kegiatan dan informasi di lingkungan RT. Dengan RT Elektronik Mobile, pengguna dapat dengan mudah mengakses berbagai fitur dan layanan yang berkaitan dengan kehidupan sehari-hari di lingkungan RT.

Aplikasi ini menyediakan berbagai fitur penting seperti pengumuman RT, jadwal kegiatan, daftar anggota RT, manajemen keuangan, dan pelaporan masalah. Pengguna dapat dengan cepat mendapatkan informasi terkini tentang acara atau perubahan penting di lingkungan RT, seperti pertemuan warga, pembersihan jalan, atau kegiatan sosial.

Selain itu, aplikasi ini juga memudahkan pengguna dalam mengelola keuangan RT. Pengguna dapat mencatat dan melacak transaksi keuangan seperti pembayaran iuran warga, pengeluaran rutin RT, atau pengumpulan dana untuk kegiatan RT. Dengan fitur manajemen keuangan yang terintegrasi, pengguna dapat mengelola keuangan RT dengan lebih efisien dan transparan.

Selain itu, RT Elektronik Mobile juga memberikan fasilitas pelaporan masalah. Jika ada masalah atau permasalahan di lingkungan RT, pengguna dapat dengan mudah melaporkannya melalui aplikasi ini. Misalnya, pengguna dapat melaporkan kerusakan fasilitas umum, gangguan keamanan, atau keluhan lainnya. Tim pengelola RT dapat dengan cepat merespons dan mengatasi masalah tersebut untuk meningkatkan kenyamanan dan keamanan lingkungan RT.

Dengan antarmuka yang intuitif dan mudah digunakan, RT Elektronik Mobile menjadikan pengelolaan RT lebih efisien dan terorganisir. Aplikasi ini memungkinkan pengguna untuk tetap terhubung dengan komunitas RT, mendapatkan informasi yang relevan, serta berpartisipasi dalam kegiatan dan pengambilan keputusan yang berkaitan dengan lingkungan mereka.

RT Elektronik Mobile adalah solusi praktis dan efektif untuk memperkuat komunikasi, transparansi, dan kolaborasi antara warga RT dalam mengelola dan memajukan lingkungan mereka.

### Note...!!!
<h4>Membutuhkan minimal API level 26 (Android 8.0)</h4>

## File Laporan :

https://drive.google.com/drive/folders/1TFGjkOGvu5J_O7-JOLunPzIvzZd1hM3Z?usp=sharing
